# Order Tracking Setup — Google Sheet (5 minutes, free)

## 1. Create the Sheet
1. Go to [sheets.google.com](https://sheets.google.com) → create a new blank sheet.
2. Rename it something like **"The High Joint — Orders"**.

## 2. Add the script
1. In the Sheet, click **Extensions → Apps Script**.
2. Delete any starter code in the editor.
3. Paste in the contents of `Code.gs` (included alongside this file).
4. Click the **Save** icon (💾).

## 3. Deploy as a Web App
1. Click **Deploy → New deployment**.
2. Click the gear icon next to "Select type" → choose **Web app**.
3. Fill in:
   - **Description:** Order logger (anything you like)
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**.
5. Google may ask you to authorize the script — click **Authorize access**, choose your Google account, then **Advanced → Go to [project name] (unsafe)** → **Allow**. (This warning is normal for your own scripts — it's not actually unsafe.)
6. Copy the **Web app URL** it gives you (ends in `/exec`).

## 4. Connect it to your website
1. Open `the-high-joint-demo.html`.
2. Find this line near the top of the `<script>` section:
   ```js
   const GAS_URL = ''; // TODO: paste your Google Apps Script Web App URL here
   ```
3. Paste your URL between the quotes:
   ```js
   const GAS_URL = 'https://script.google.com/macros/s/XXXXXXXXXXXX/exec';
   ```
4. Save and re-upload the file.

## That's it
Every order placed on the site (COD or UPI) will now silently add a row to your **Orders** sheet — timestamp, order number, customer name, phone, order type, address, payment method, items, and total. You can open the sheet anytime, sort/filter it, or download it as Excel/CSV.

### Notes
- If you ever change the code in Apps Script, you need to **Deploy → Manage deployments → Edit (pencil) → New version → Deploy** again for changes to take effect.
- This is a "fire and forget" call from the browser — it doesn't slow down or block the customer's order if it fails for any reason.
- Since Sheets isn't a real database, if you outgrow this later (very high order volume), the same script logic can be pointed at a proper database with minimal changes.
