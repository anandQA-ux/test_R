/**
 * The High Joint — Order Logger
 * Paste this into Extensions > Apps Script on your Google Sheet, then
 * deploy as a Web App (see SETUP.md for full steps).
 */
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Orders');
  if (!sheet) {
    sheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet('Orders');
    sheet.appendRow(['Timestamp', 'Order No', 'Name', 'Phone', 'Order Type', 'Address', 'Payment', 'Items', 'Total (₹)']);
  }

  var data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    new Date(),
    data.orderNo || '',
    data.name || '',
    data.phone || '',
    data.orderType || '',
    data.address || '',
    data.payment || '',
    data.items || '',
    data.total || ''
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok' }))
    .setMimeType(ContentService.MimeType.JSON);
}
